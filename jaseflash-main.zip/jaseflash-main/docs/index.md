---
page_title: "scaffolding Provider"
subcategory: ""
description: |-
  
---

# scaffolding Provider



## Example Usage

```terraform
provider "scaffolding" {
  # example configuration here
}
```

## Schema
