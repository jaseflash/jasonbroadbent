kubectl delete deployment backend
kubectl delete service backend
kubectl delete serviceaccount backend
kubectl delete servicedefaults backend
kubectl delete serviceresolver backend
kubectl delete serviceintentions backend
