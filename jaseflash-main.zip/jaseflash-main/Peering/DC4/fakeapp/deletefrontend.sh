kubectl delete deployment frontend
kubectl delete service frontend
kubectl delete serviceaccount frontend
kubectl delete servicedefaults frontend
