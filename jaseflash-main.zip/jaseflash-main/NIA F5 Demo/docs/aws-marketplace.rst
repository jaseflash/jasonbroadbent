AWS Marketplace
===============

If you see the following error you will need to complete this section.

Otherwise you can skip to the next section.

.. image:: ./images/aws-marketplace-error.png

Either follow the URL or click on the "AWS Marketplace" bookmark in Chrome.

Click on "Subscribe"

.. image:: ./images/aws-marketplace-subscribe.png

Click on "Accept Terms"

.. image:: ./images/aws-marketplace-accept-terms.png           

Go back to the Ubuntu host and re-run

.. code-block:: shell

  $ terraform apply           
